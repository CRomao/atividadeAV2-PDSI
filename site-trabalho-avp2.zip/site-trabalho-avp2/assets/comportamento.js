var btnMenu = document.querySelector(".menu-hamburguer");

btnMenu.addEventListener("click", function() {
	console.log("Esse método será chamado quando um clique for dado no elemento com a classe .menu-hamburguer");
});